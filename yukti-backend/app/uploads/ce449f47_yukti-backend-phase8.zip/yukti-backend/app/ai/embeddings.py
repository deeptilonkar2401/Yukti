"""
Wraps Sentence Transformers so the rest of the app never touches the
model directly. The model is loaded once, lazily, on first use — not at
import time — so `uvicorn app.main:app` still starts fast and other
routes work even before the ~90MB model has been downloaded/loaded.
"""
from functools import lru_cache

import numpy as np

_MODEL_NAME = "all-MiniLM-L6-v2"  # small (~90MB), fast, good enough for this use case


@lru_cache(maxsize=1)
def _get_model():
    from sentence_transformers import SentenceTransformer

    return SentenceTransformer(_MODEL_NAME)


def embed_text(text: str) -> list[float]:
    """Returns a 384-dim embedding as a plain list (JSON-serializable, for storing in the DB)."""
    model = _get_model()
    vector = model.encode(text, normalize_embeddings=True)
    return vector.tolist()


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Both inputs should already be normalized (embed_text does this), so this is just a dot product."""
    va, vb = np.array(a), np.array(b)
    denom = (np.linalg.norm(va) * np.linalg.norm(vb)) or 1e-8
    return float(np.dot(va, vb) / denom)
