import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.database import get_db
from app.models.user import User, UserRole
from app.models.industry import Industry
from app.schemas.industry import IndustryCreate, IndustryRead

router = APIRouter(prefix="/api/industries", tags=["industries"])


@router.post("/me", response_model=IndustryRead, status_code=status.HTTP_201_CREATED)
def create_my_industry(
    payload: IndustryCreate,
    current_user: User = Depends(require_roles(UserRole.industry)),
    db: Session = Depends(get_db),
):
    existing = db.query(Industry).filter(Industry.user_id == current_user.id).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Industry profile already exists")

    industry = Industry(user_id=current_user.id, **payload.model_dump())
    db.add(industry)
    db.commit()
    db.refresh(industry)
    return industry


@router.get("/me", response_model=IndustryRead)
def get_my_industry(
    current_user: User = Depends(require_roles(UserRole.industry)),
    db: Session = Depends(get_db),
):
    industry = db.query(Industry).filter(Industry.user_id == current_user.id).first()
    if industry is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No industry profile yet — create one first with POST /api/industries/me",
        )
    return industry


@router.get("", response_model=list[IndustryRead])
def list_industries(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Industry).all()


@router.get("/{industry_id}", response_model=IndustryRead)
def get_industry(
    industry_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    industry = db.query(Industry).filter(Industry.id == industry_id).first()
    if not industry:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Industry not found")
    return industry
