import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.ai.matching import score_university_for_problem, score_industry_for_problem
from app.database import get_db
from app.models.user import User, UserRole
from app.models.problem import Problem, ProblemStatus
from app.models.university import University
from app.models.industry import Industry
from app.models.claim import Claim, ClaimStatus, ClaimantType
from app.models.project import Project
from app.schemas.claim import ClaimCreate, ClaimRead, ClaimRespond
from app.services.notifications import notify_user

router = APIRouter(prefix="/api/claims", tags=["claims"])


def _org_ids_for_user(current_user: User, db: Session) -> tuple[uuid.UUID | None, uuid.UUID | None]:
    """Returns (university_id, industry_id) — whichever applies to this user, else None."""
    if current_user.role == UserRole.university:
        org = db.query(University).filter(University.user_id == current_user.id).first()
        return (org.id if org else None), None
    if current_user.role == UserRole.industry:
        org = db.query(Industry).filter(Industry.user_id == current_user.id).first()
        return None, (org.id if org else None)
    return None, None


@router.post("", response_model=ClaimRead, status_code=status.HTTP_201_CREATED)
def create_claim(
    payload: ClaimCreate,
    current_user: User = Depends(require_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    """
    Admin proposes: "this problem suits this university/industry".
    Manual for now — Phase 6's AI matching will call this same shape
    programmatically once match_score/breakdown are computed automatically.
    """
    problem = db.query(Problem).filter(Problem.id == payload.problem_id).first()
    if not problem:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Problem not found")
    if problem.status not in (ProblemStatus.verified, ProblemStatus.matched):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only verified problems can be matched to a university/industry",
        )

    if payload.claimant_type == ClaimantType.university:
        if payload.university_id is None:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="university_id is required")
        university = db.query(University).filter(University.id == payload.university_id).first()
        if not university:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="University not found")
        score_result = score_university_for_problem(problem, university)
    else:
        if payload.industry_id is None:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="industry_id is required")
        industry = db.query(Industry).filter(Industry.id == payload.industry_id).first()
        if not industry:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Industry not found")
        score_result = score_industry_for_problem(problem, industry)

    claim = Claim(
        problem_id=payload.problem_id,
        claimant_type=payload.claimant_type,
        university_id=payload.university_id,
        industry_id=payload.industry_id,
        **score_result,
    )
    db.add(claim)

    if problem.status == ProblemStatus.verified:
        problem.status = ProblemStatus.matched

    db.commit()
    db.refresh(claim)

    org_user_id = university.user_id if payload.claimant_type == ClaimantType.university else industry.user_id
    notify_user(
        db,
        org_user_id,
        title="New problem match proposed",
        body=f'"{problem.title}" ({problem.domain}) has been matched to you — review and respond.',
        data={"type": "claim_proposed", "claim_id": str(claim.id), "problem_id": str(problem.id)},
    )

    return claim


@router.get("/mine", response_model=list[ClaimRead])
def list_my_claims(
    current_user: User = Depends(require_roles(UserRole.university, UserRole.industry)),
    db: Session = Depends(get_db),
):
    university_id, industry_id = _org_ids_for_user(current_user, db)
    query = db.query(Claim)
    if current_user.role == UserRole.university:
        query = query.filter(Claim.university_id == university_id)
    else:
        query = query.filter(Claim.industry_id == industry_id)
    return query.order_by(Claim.created_at.desc()).all()


@router.get("", response_model=list[ClaimRead])
def list_all_claims(
    problem_id: uuid.UUID | None = None,
    status_filter: ClaimStatus | None = None,
    current_user: User = Depends(require_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    query = db.query(Claim)
    if problem_id:
        query = query.filter(Claim.problem_id == problem_id)
    if status_filter:
        query = query.filter(Claim.status == status_filter)
    return query.order_by(Claim.created_at.desc()).all()


@router.patch("/{claim_id}/respond", response_model=ClaimRead)
def respond_to_claim(
    claim_id: uuid.UUID,
    payload: ClaimRespond,
    current_user: User = Depends(require_roles(UserRole.university, UserRole.industry)),
    db: Session = Depends(get_db),
):
    """The claimed university/industry accepts or rejects the proposed match."""
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found")

    university_id, industry_id = _org_ids_for_user(current_user, db)
    is_owner = (
        (claim.claimant_type == ClaimantType.university and claim.university_id == university_id)
        or (claim.claimant_type == ClaimantType.industry and claim.industry_id == industry_id)
    )
    if not is_owner:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This claim wasn't proposed to you")

    if claim.status != ClaimStatus.pending:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="This claim was already responded to")

    claim.status = payload.status
    claim.responded_at = datetime.utcnow()

    problem = db.query(Problem).filter(Problem.id == claim.problem_id).first()

    if payload.status == ClaimStatus.rejected:
        # Free the problem up so admin can propose a different match.
        if problem and problem.status == ProblemStatus.matched:
            problem.status = ProblemStatus.verified
    elif payload.status == ClaimStatus.accepted:
        if problem:
            problem.status = ProblemStatus.in_progress
        partner_name = None
        if claim.claimant_type == ClaimantType.university:
            org = db.query(University).filter(University.id == claim.university_id).first()
            partner_name = org.institute_name if org else None
        else:
            org = db.query(Industry).filter(Industry.id == claim.industry_id).first()
            partner_name = org.company_name if org else None

        db.add(Project(claim_id=claim.id, problem_id=claim.problem_id, partner_name=partner_name))

    db.commit()
    db.refresh(claim)

    if problem:
        if payload.status == ClaimStatus.accepted:
            notify_user(
                db,
                problem.submitted_by,
                title="A partner has taken up your problem",
                body=f'"{problem.title}" is now being worked on by {partner_name or "a partner organization"}.',
                data={"type": "claim_accepted", "problem_id": str(problem.id)},
            )

    return claim
