from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.database import get_db
from app.models.problem import Problem, ProblemStatus
from app.schemas.geo import GeoJSONFeature, GeoJSONFeatureCollection, GeoJSONGeometry, ProblemProperties

router = APIRouter(prefix="/api/geo", tags=["geo"])


@router.get("/problems", response_model=GeoJSONFeatureCollection)
def get_problems_geojson(
    domain: str | None = None,
    status_filter: ProblemStatus | None = None,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    GeoJSON FeatureCollection — feed this straight into a Leaflet
    L.geoJSON(...) layer. Only problems with a location are included
    (problems submitted without coordinates are just skipped, not errored).
    """
    from geoalchemy2.shape import to_shape

    query = db.query(Problem).filter(Problem.location.isnot(None))
    if domain:
        query = query.filter(Problem.domain == domain)
    if status_filter:
        query = query.filter(Problem.status == status_filter)

    features = []
    for problem in query.all():
        point = to_shape(problem.location)  # shapely Point; .x = longitude, .y = latitude
        features.append(
            GeoJSONFeature(
                geometry=GeoJSONGeometry(coordinates=[point.x, point.y]),
                properties=ProblemProperties(
                    id=problem.id,
                    title=problem.title,
                    domain=problem.domain,
                    subdomain=problem.subdomain,
                    priority=problem.priority.value,
                    status=problem.status.value,
                    location_text=problem.location_text,
                ),
            )
        )

    return GeoJSONFeatureCollection(features=features)
