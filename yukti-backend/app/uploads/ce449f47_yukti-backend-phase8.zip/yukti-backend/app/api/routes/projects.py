import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.database import get_db
from app.models.user import User, UserRole
from app.models.claim import Claim, ClaimantType
from app.models.project import Project
from app.models.university import University
from app.models.industry import Industry
from app.schemas.project import ProjectRead, ProjectUpdate

router = APIRouter(prefix="/api/projects", tags=["projects"])


def _is_project_owner(current_user: User, project: Project, db: Session) -> bool:
    if current_user.role == UserRole.admin:
        return True
    claim = db.query(Claim).filter(Claim.id == project.claim_id).first()
    if not claim:
        return False
    if current_user.role == UserRole.university and claim.claimant_type == ClaimantType.university:
        org = db.query(University).filter(University.user_id == current_user.id).first()
        return bool(org and org.id == claim.university_id)
    if current_user.role == UserRole.industry and claim.claimant_type == ClaimantType.industry:
        org = db.query(Industry).filter(Industry.user_id == current_user.id).first()
        return bool(org and org.id == claim.industry_id)
    return False


@router.get("/mine", response_model=list[ProjectRead])
def list_my_projects(
    current_user: User = Depends(require_roles(UserRole.university, UserRole.industry)),
    db: Session = Depends(get_db),
):
    claimant_type = ClaimantType.university if current_user.role == UserRole.university else ClaimantType.industry
    if claimant_type == ClaimantType.university:
        org = db.query(University).filter(University.user_id == current_user.id).first()
        org_filter = Claim.university_id == (org.id if org else None)
    else:
        org = db.query(Industry).filter(Industry.user_id == current_user.id).first()
        org_filter = Claim.industry_id == (org.id if org else None)

    return (
        db.query(Project)
        .join(Claim, Project.claim_id == Claim.id)
        .filter(Claim.claimant_type == claimant_type, org_filter)
        .all()
    )


@router.get("", response_model=list[ProjectRead], dependencies=[Depends(require_roles(UserRole.admin))])
def list_all_projects(db: Session = Depends(get_db)):
    return db.query(Project).all()


@router.get("/{project_id}", response_model=ProjectRead)
def get_project(
    project_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    if not _is_project_owner(current_user, project, db):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your project")
    return project


@router.patch("/{project_id}", response_model=ProjectRead)
def update_project(
    project_id: uuid.UUID,
    payload: ProjectUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Owning university/industry (or admin) updates milestones/status as work progresses."""
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    if not _is_project_owner(current_user, project, db):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your project")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(project, field, value)

    db.commit()
    db.refresh(project)
    return project
