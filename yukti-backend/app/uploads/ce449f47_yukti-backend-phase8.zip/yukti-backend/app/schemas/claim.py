import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.claim import ClaimantType, ClaimStatus


class ClaimCreate(BaseModel):
    """
    Admin creates this to propose a match: "this problem suits this
    university/industry". Phase 6's AI matching will eventually create
    these automatically (and fill match_score/breakdown) instead of an
    admin picking manually — the shape stays the same either way.
    """
    problem_id: uuid.UUID
    claimant_type: ClaimantType
    university_id: uuid.UUID | None = None
    industry_id: uuid.UUID | None = None


class ClaimRespond(BaseModel):
    status: ClaimStatus  # accepted / rejected


class ClaimRead(BaseModel):
    id: uuid.UUID
    problem_id: uuid.UUID
    claimant_type: ClaimantType
    status: ClaimStatus
    match_score: int | None = None
    match_breakdown: dict | None = None
    matched_skills: list[str] | None = None
    why_matched: list[str] | None = None
    created_at: datetime

    class Config:
        from_attributes = True
