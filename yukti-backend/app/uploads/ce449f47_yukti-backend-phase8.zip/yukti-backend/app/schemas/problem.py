import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.problem import ProblemPriority, ProblemStatus
from app.schemas.media import MediaRead


class ProblemBase(BaseModel):
    title: str
    description: str
    domain: str
    subdomain: str | None = None
    priority: ProblemPriority = ProblemPriority.medium
    location_text: str | None = None
    population_affected: str | None = None


class ProblemCreate(ProblemBase):
    latitude: float | None = None
    longitude: float | None = None


class ProblemRead(ProblemBase):
    id: uuid.UUID
    status: ProblemStatus
    submitted_by: uuid.UUID
    created_at: datetime

    class Config:
        from_attributes = True


class ProblemDetailRead(ProblemRead):
    media: list[MediaRead] = []

    class Config:
        from_attributes = True


class DuplicateMatch(BaseModel):
    id: uuid.UUID
    title: str
    similarity: float  # 0.0 - 1.0


class ProblemCreateResponse(ProblemRead):
    """Same as ProblemRead, plus any likely duplicates found at submission time."""
    possible_duplicates: list[DuplicateMatch] = []


class ProblemSummaryResponse(BaseModel):
    problem_id: uuid.UUID
    summary: str


class ProblemStatusUpdate(BaseModel):
    status: ProblemStatus  # admin moves it forward, e.g. submitted -> verified
