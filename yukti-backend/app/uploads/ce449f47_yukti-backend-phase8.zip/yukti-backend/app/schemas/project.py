import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.project import ProjectStatus


class ProjectRead(BaseModel):
    id: uuid.UUID
    claim_id: uuid.UUID
    problem_id: uuid.UUID
    lead_name: str | None = None
    partner_name: str | None = None
    status: ProjectStatus
    milestones: list[bool] | None = None
    created_at: datetime

    class Config:
        from_attributes = True


class ProjectUpdate(BaseModel):
    """All fields optional — send only what you're changing."""
    lead_name: str | None = None
    partner_name: str | None = None
    status: ProjectStatus | None = None
    milestones: list[bool] | None = None
