import uuid

from pydantic import BaseModel


class IndustryCreate(BaseModel):
    company_name: str
    sector: str | None = None
    csr_focus_area: str | None = None


class IndustryRead(BaseModel):
    id: uuid.UUID
    company_name: str
    sector: str | None = None
    csr_focus_area: str | None = None

    class Config:
        from_attributes = True
