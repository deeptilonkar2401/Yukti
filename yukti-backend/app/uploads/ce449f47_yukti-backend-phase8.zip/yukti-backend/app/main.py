from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app import models  # noqa: F401 — registers all models on Base.metadata
from app.api.routes import auth, users, problems, universities, industries, claims, projects, matching, geo, dashboard, notifications

app = FastAPI(
    title="YUKTI API",
    description="Backend for the YUKTI crowdsourced problem-solving platform (SIH PS26043).",
    version="0.1.0",
)

# Vite dev server default is :5173. Add your deployed frontend URL(s) here too
# once you deploy to Vercel — wildcard "*" doesn't work together with
# allow_credentials=True in browsers, so list origins explicitly.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(problems.router)
app.include_router(universities.router)
app.include_router(industries.router)
app.include_router(claims.router)
app.include_router(projects.router)
app.include_router(matching.router)
app.include_router(geo.router)
app.include_router(dashboard.router)
app.include_router(notifications.router)


@app.on_event("startup")
def on_startup():
    # Prototype convenience only — use Alembic migrations once schema stabilizes.
    Base.metadata.create_all(bind=engine)


@app.get("/")
def health_check():
    return {"status": "ok", "service": "YUKTI API"}
